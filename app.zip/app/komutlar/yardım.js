const Discord = require("discord.js")
module.exports.run= async(client, message, args) => {
let cse = new Discord.MessageEmbed()//discord.gg/turkiye
.setTitle(client.user.username+" Yardım Menüsü")
.setColor("BLUE")
.setThumbnail(client.user.avatarURL())
.setDescription(`.kick
.ban
.yaz
.rol
.ascii
.emojiler
.sunucu-bilgi
.kullanıcı-bilgi
.ping
.uptime
.oynuyor
.nuke
.saat
.unban
.sil
.istatistik
.emoji-yükle
.banlananlar
.lock
.unlock
.çek
.ses
`)
.setFooter("Dr Yazıcı")
.setTimestamp()
message.channel.send(cse)
}
module.exports.conf = {
aliases: []
}

module.exports.help = {
name: "yardım"
}