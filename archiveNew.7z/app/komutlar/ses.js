const Discord = require('discord.js')
exports.run = async(client, message, args) => {

let user = message.mentions.members.first()

if(!message.member.permissions.has('ADMINISTRATOR')) return message.channel.send("**❌ Bu komutu kullanabilmek için YÖNETİCİ iznine sahip olmanız gerek.**").then(x => x.delete({timeout: 10000}))

if(!user) return message.channel.send("** Bir üyeyi etiketle veya bir kullanıcı ID belirt.**")

let sonuc; if(!user.voice.channelID) sonuc = `${user} Adlı kullanıcı bir sesli kanalda bulunmuyor.`; if(user.voice.channelID) sonuc = `${user} Adlı kullanıcı \`${user.voice.channel.name}\`İsimli odada bulunuyor.`

message.channel.send(sonuc)

}
exports.conf = {
enabled: true,
guildOnly: true,
aliases: ['seskontrol']
}
    
exports.help = {
name: 'ses'
};
